/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package quanlythietbimang;


public class BoNhoTam {

    private static TaiKhoan User;

    public static TaiKhoan getUser() {
        return User;
    }

    public static void setUser(TaiKhoan tk) {
        BoNhoTam.User = tk;
    }
}
