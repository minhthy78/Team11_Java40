/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package quanlythietbimang;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;


public class SQLEmail {
     private Connection ketnoi;

    public SQLEmail() {
        this.ketnoi = KetNoiSQL.getConnection();
    }

    public void insert(String email, String password) {
        try (CallableStatement thutuc = ketnoi.prepareCall("{call sp_Email_Insert(?,?)}")) {
            thutuc.setString(1, email);
            thutuc.setString(2, password);

            thutuc.execute();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Lỗi: " + ex.getMessage());
        }
    }

    public Email getEmail() {
        Email mailGui = new Email();
        try (CallableStatement thutuc = ketnoi.prepareCall("{call sp_Email_Select()}")) {
            thutuc.execute();
            ResultSet resultSet = thutuc.getResultSet();

            while (resultSet.next()) {
                String email = resultSet.getString("Email");
                String password = resultSet.getString("Password");
              
                mailGui.setEmail(email);
                mailGui.setPassword(password);
                
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Lỗi: " + ex.getMessage());
        }
        return mailGui;
    }
}
