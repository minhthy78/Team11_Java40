/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package quanlythietbimang;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;


public class SQLTaiKhoan {

    private Connection ketnoi;

    public SQLTaiKhoan() {
        this.ketnoi = KetNoiSQL.getConnection();
    }

    public void insert(String username, String password, String hoten, String email, Boolean vaitro) {
        try (CallableStatement thutuc = ketnoi.prepareCall("{call sp_TaiKhoan_Insert(?,?,?,?,?)}")) {
            thutuc.setString(1, username);
            thutuc.setString(2, password);
            thutuc.setString(3, hoten);
            thutuc.setString(4, email);
            thutuc.setBoolean(5, vaitro);
            thutuc.execute();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Lỗi: " + ex.getMessage());
        }
    }

    public void update(String username, String hoten, String email, Boolean vaitro) {
        try (CallableStatement thutuc = ketnoi.prepareCall("{call sp_TaiKhoan_Update(?,?,?,?)}")) {
            thutuc.setString(1, username);
            thutuc.setString(2, hoten);
            thutuc.setString(3, email);
            thutuc.setBoolean(4, vaitro);
            thutuc.execute();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Lỗi: " + ex.getMessage());
        }
    }

    public void delete(String username) {
        try (CallableStatement thutuc = ketnoi.prepareCall("{call sp_TaiKhoan_Delete(?)}")) {
            thutuc.setString(1, username);
            thutuc.execute();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Lỗi: " + ex.getMessage());
        }
    }

    public void DoiMatKhau(String username, String password) {
        try (CallableStatement thutuc = ketnoi.prepareCall("{call sp_TaiKhoan_ChangePassword(?, ?)}")) {
            thutuc.setString(1, username);
            thutuc.setString(2, password);
            thutuc.execute();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Lỗi: " + ex.getMessage());
        }
    }

    public List<TaiKhoan> getAll() {
        List<TaiKhoan> dsTaiKhoan = new ArrayList<>();
        try (CallableStatement thutuc = ketnoi.prepareCall("{call sp_TaiKhoan_SelectAll()}")) {
            thutuc.execute();
            ResultSet resultSet = thutuc.getResultSet();

            while (resultSet.next()) {
                String username = resultSet.getString("Username");
                String hoten = resultSet.getString("HoTen");
                String email = resultSet.getString("Email");
                Boolean vaitro = resultSet.getBoolean("VaiTro");

                TaiKhoan taikhoan = new TaiKhoan();
                taikhoan.setUsername(username);
                taikhoan.setHoTen(hoten);
                taikhoan.setEmail(email);
                taikhoan.setVaiTro(vaitro);

                dsTaiKhoan.add(taikhoan);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Lỗi: " + ex.getMessage());
        }
        return dsTaiKhoan;
    }

    public Boolean login(String username, String password) {
        Boolean kqLogin = false;
        try (CallableStatement thutuc = ketnoi.prepareCall("{call sp_TaiKhoan_CheckLogin(?,?)}")) {
            thutuc.setString(1, username);
            thutuc.setString(2, password);
            thutuc.execute();
            ResultSet resultSet = thutuc.getResultSet();

            while (resultSet.next()) {
                kqLogin = resultSet.getBoolean("KetQua");
                if (kqLogin == true) {

                    String hoten = resultSet.getString("HoTen");
                    String email = resultSet.getString("Email");
                    Boolean vaitro = resultSet.getBoolean("VaiTro");

                    TaiKhoan taikhoan = new TaiKhoan();
                    taikhoan.setUsername(username);
                    taikhoan.setHoTen(hoten);
                    taikhoan.setEmail(email);
                    taikhoan.setVaiTro(vaitro);

                    // Lưu vào bộ nhớ tạm
                    BoNhoTam.setUser(taikhoan);
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Lỗi sql login: " + ex.getMessage());
        }
        return kqLogin;
    }
}
