/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package quanlythietbimang;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;


public class SQLLogThietBi {
     private Connection ketnoi;

    public SQLLogThietBi() {
        this.ketnoi = KetNoiSQL.getConnection();
    }

    public void insert(int mathietbi, Boolean tinhtrang) {
        try (CallableStatement thutuc = ketnoi.prepareCall("{call sp_LogThietBi_Insert(?,?)}")) {
            thutuc.setInt(1, mathietbi);
            thutuc.setBoolean(2, tinhtrang);
            thutuc.execute();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Lỗi: " + ex.getMessage());
        }
    }
    
    public List<LogThietBi> getAll() {
        List<LogThietBi> dsLog = new ArrayList<>();
        try (CallableStatement thutuc = ketnoi.prepareCall("{call sp_Log_SelectAll()}")) {
            thutuc.execute();
            ResultSet resultSet = thutuc.getResultSet();

            while (resultSet.next()) {
                int id = resultSet.getInt("MaThietBi");
                String name = resultSet.getString("TenThietBi");
                Boolean status = resultSet.getBoolean("TinhTrang");
                String ip = resultSet.getString("Ip");
                String khu = resultSet.getString("MaKhu");
                int loai = resultSet.getInt("LoaiThietBi");
                String tenKhu = resultSet.getString("TenKhu");
                String tenLoai = resultSet.getString("TenLoai");
                String thoiGian = resultSet.getString("ThoiGian");

                ThietBi thietbi = new ThietBi();
                thietbi.setIp(ip);
                thietbi.setMa(id);
                thietbi.setTinhtrang(status);
                thietbi.setTen(name);
                thietbi.setKhu(khu);
                thietbi.setLoai(loai);
                thietbi.setTenKhu(tenKhu);
                thietbi.setTenLoai(tenLoai);
                
                LogThietBi log = new LogThietBi(thietbi, thoiGian);
                dsLog.add(log);
                
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Lỗi: " + ex.getMessage());
        }
        return dsLog;
    }
    
    public List<LogThietBi> getByMaThietBi(int MaThietBi) {
        List<LogThietBi> dsLog = new ArrayList<>();
        try (CallableStatement thutuc = ketnoi.prepareCall("{call sp_LogThietBi_SelectByMaThietBi(?)}")) {
            thutuc.setInt(1, MaThietBi);
            thutuc.execute();
            ResultSet resultSet = thutuc.getResultSet();

            while (resultSet.next()) {
                int id = resultSet.getInt("MaThietBi");
                String name = resultSet.getString("TenThietBi");
                Boolean status = resultSet.getBoolean("TinhTrang");
                String ip = resultSet.getString("Ip");
                String khu = resultSet.getString("MaKhu");
                int loai = resultSet.getInt("LoaiThietBi");
                String tenKhu = resultSet.getString("TenKhu");
                String tenLoai = resultSet.getString("TenLoai");
                String thoiGian = resultSet.getString("ThoiGian");

                ThietBi thietbi = new ThietBi();
                thietbi.setIp(ip);
                thietbi.setMa(id);
                thietbi.setTinhtrang(status);
                thietbi.setTen(name);
                thietbi.setKhu(khu);
                thietbi.setLoai(loai);
                thietbi.setTenKhu(tenKhu);
                thietbi.setTenLoai(tenLoai);
                
                LogThietBi log = new LogThietBi(thietbi, thoiGian);
                dsLog.add(log);                
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Lỗi: " + ex.getMessage());
        }
        return dsLog;
    }
}
