/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package quanlythietbimang;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;


public class SQLKhu {
    private Connection ketnoi;

    public SQLKhu() {
        this.ketnoi = KetNoiSQL.getConnection();
    }

    public void insert(String ma, String ten) {
        try (CallableStatement thutuc = ketnoi.prepareCall("{call sp_Khu_Insert(?,?)}")) {
            thutuc.setString(1, ma);
            thutuc.setString(2, ten);

            thutuc.execute();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Lỗi: " + ex.getMessage());
        }
    }
    
    public void update(String ma, String ten) {
        try (CallableStatement thutuc = ketnoi.prepareCall("{call sp_Khu_Update(?,?)}")) {
            thutuc.setString(1, ma);
            thutuc.setString(2, ten);
            thutuc.execute();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Lỗi: " + ex.getMessage());
        }
    }
    
    public void delete(String ma) {
        try (CallableStatement thutuc = ketnoi.prepareCall("{call sp_Khu_Delete(?)}")) {
            thutuc.setString(1, ma);         
            thutuc.execute();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Lỗi: " + ex.getMessage());
        }
    }
    
    public List<Khu> getAll() {
        List<Khu> dsKhu = new ArrayList<>();
        try (CallableStatement thutuc = ketnoi.prepareCall("{call sp_Khu_SelectAll()}")) {
            thutuc.execute();
            ResultSet resultSet = thutuc.getResultSet();

            while (resultSet.next()) {
                String id = resultSet.getString("MaKhu");
                String name = resultSet.getString("TenKhu");
              
                Khu khu = new Khu();
                khu.setMaKhu(id);
                khu.setTenKhu(name);
                dsKhu.add(khu);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Lỗi: " + ex.getMessage());
        }
        return dsKhu;
    }

}
