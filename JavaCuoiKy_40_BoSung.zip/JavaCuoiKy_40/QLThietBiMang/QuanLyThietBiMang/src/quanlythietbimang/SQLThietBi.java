/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package quanlythietbimang;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class SQLThietBi {

    private Connection ketnoi;

    public SQLThietBi() {
        this.ketnoi = KetNoiSQL.getConnection();
    }

    public void insert(String ten, String ip, String khu, int loai) {
        try (CallableStatement thutuc = ketnoi.prepareCall("{call sp_ThietBi_Insert(?,?,?,?)}")) {
            thutuc.setString(1, ten);
            thutuc.setString(2, ip);
            thutuc.setString(3, khu);
            thutuc.setInt(4, loai);
            thutuc.execute();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Lỗi: " + ex.getMessage());
        }
    }

    public void update(int ma, String ten, String ip, String khu, int loai) {
        try (CallableStatement thutuc = ketnoi.prepareCall("{call sp_ThietBi_Update(?,?,?,?,?)}")) {
            thutuc.setInt(1, ma);
            thutuc.setString(2, ten);
            thutuc.setString(3, ip);
            thutuc.setString(3, khu);
            thutuc.setInt(5, loai);
            thutuc.execute();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Lỗi: " + ex.getMessage());
        }
    }
    
    public void updateTinhTrang(int ma, Boolean tinhtrang) {
        try (CallableStatement thutuc = ketnoi.prepareCall("{call sp_ThietBi_Update_TinhTrang(?,?)}")) {
            thutuc.setInt(1, ma);
            thutuc.setBoolean(2, tinhtrang);
            thutuc.execute();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Lỗi: " + ex.getMessage());
        }
    }

    public void delete(int ma) {
        try (CallableStatement thutuc = ketnoi.prepareCall("{call sp_ThietBi_Delete(?)}")) {
            thutuc.setInt(1, ma);
            thutuc.execute();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Lỗi: " + ex.getMessage());
        }
    }
    
    public ThietBi getThietBiByID(int MaThietBi) {
        ThietBi thietbi = new ThietBi();
        try (CallableStatement thutuc = ketnoi.prepareCall("{call sp_ThietBi_SelectByID(?)}")) {
            thutuc.setInt(1, MaThietBi);
            thutuc.execute();
            ResultSet resultSet = thutuc.getResultSet();

            while (resultSet.next()) {
                int id = resultSet.getInt("MaThietBi");
                String name = resultSet.getString("TenThietBi");
                Boolean status = resultSet.getBoolean("TinhTrang");
                String ip = resultSet.getString("Ip");
                String khu = resultSet.getString("MaKhu");
                int loai = resultSet.getInt("LoaiThietBi");

                
                thietbi.setIp(ip);
                thietbi.setMa(id);
                thietbi.setTinhtrang(status);
                thietbi.setTen(name);
                thietbi.setKhu(khu);
                thietbi.setLoai(loai);

            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Lỗi: " + ex.getMessage());
        }
        return thietbi;
    }
    

    public List<ThietBi> getAll() {
        List<ThietBi> dsThietBi = new ArrayList<>();
        try (CallableStatement thutuc = ketnoi.prepareCall("{call sp_ThietBi_SelectAll()}")) {
            thutuc.execute();
            ResultSet resultSet = thutuc.getResultSet();

            while (resultSet.next()) {
                int id = resultSet.getInt("MaThietBi");
                String name = resultSet.getString("TenThietBi");
                Boolean status = resultSet.getBoolean("TinhTrang");
                String ip = resultSet.getString("Ip");
                String khu = resultSet.getString("MaKhu");
                int loai = resultSet.getInt("LoaiThietBi");
                String tenKhu = resultSet.getString("TenKhu");
                String tenLoai = resultSet.getString("TenLoai");


                ThietBi thietbi = new ThietBi();
                thietbi.setIp(ip);
                thietbi.setMa(id);
                thietbi.setTinhtrang(status);
                thietbi.setTen(name);
                thietbi.setKhu(khu);
                thietbi.setLoai(loai);
                thietbi.setTenKhu(tenKhu);
                thietbi.setTenLoai(tenLoai);

                dsThietBi.add(thietbi);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Lỗi: " + ex.getMessage());
        }
        return dsThietBi;
    }
}
