/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package quanlythietbimang;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import javax.swing.JOptionPane;


public class SQLLoaiThietBi {

    private Connection ketnoi;

    public SQLLoaiThietBi() {
        this.ketnoi = KetNoiSQL.getConnection();
    }

    public void insert(String ten) {
        try (CallableStatement thutuc = ketnoi.prepareCall("{call sp_LoaiThietBi_Insert(?)}")) {
            thutuc.setString(1, ten);
            thutuc.execute();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Lỗi: " + ex.getMessage());
        }
    }
    
    public void update(int ma, String ten) {
        try (CallableStatement thutuc = ketnoi.prepareCall("{call sp_LoaiThietBi_Update(?,?)}")) {
            thutuc.setInt(1, ma);
            thutuc.setString(2, ten);
            thutuc.execute();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Lỗi: " + ex.getMessage());
        }
    }
    
    public void delete(int ma) {
        try (CallableStatement thutuc = ketnoi.prepareCall("{call sp_LoaiThietBi_Delete(?)}")) {
            thutuc.setInt(1, ma);         
            thutuc.execute();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Lỗi: " + ex.getMessage());
        }
    }
    
    public List<LoaiThietBi> getAll() {
        List<LoaiThietBi> dsLoai = new ArrayList<>();
        try (CallableStatement thutuc = ketnoi.prepareCall("{call sp_LoaiThietBi_SelectAll()}")) {
            thutuc.execute();
            ResultSet resultSet = thutuc.getResultSet();

            while (resultSet.next()) {
                int id = resultSet.getInt("MaLoai");
                String name = resultSet.getString("TenLoai");
              
                LoaiThietBi loai = new LoaiThietBi();
                loai.setMaLoai(id);
                loai.setTenLoai(name);
                dsLoai.add(loai);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Lỗi: " + ex.getMessage());
        }
        return dsLoai;
    }

}
