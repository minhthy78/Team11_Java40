/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package quanlythietbimang;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class Ping {
   public static CompletableFuture<Boolean> pingDevice(String ipAddress) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                InetAddress inetAddress = InetAddress.getByName(ipAddress);
                if (inetAddress.isReachable(5000)) {
                    return true;
                } else {
                    return false;
                }
            } catch (Exception e) {
                return false;
            }
        });
    }

    public static CompletableFuture<List<Boolean>> pingDevices(List<String> ipAddresses) {
        List<CompletableFuture<Boolean>> pingFutures = new ArrayList<>();

        for (String ipAddress : ipAddresses) {
            pingFutures.add(pingDevice(ipAddress));
        }

        CompletableFuture<Void> allOf = CompletableFuture.allOf(pingFutures.toArray(new CompletableFuture[0]));

        return allOf.thenApply(v ->
            pingFutures.stream()
                .map(CompletableFuture::join)
                .toList()
        );
    }
 
}
