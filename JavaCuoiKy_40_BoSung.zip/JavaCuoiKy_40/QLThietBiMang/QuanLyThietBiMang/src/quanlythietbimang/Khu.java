/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package quanlythietbimang;


public class Khu {
       private String MaKhu;
       private String TenKhu;

    public String getMaKhu() {
        return MaKhu;
    }

    public void setMaKhu(String MaKhu) {
        this.MaKhu = MaKhu;
    }

    public String getTenKhu() {
        return TenKhu;
    }

    public void setTenKhu(String TenKhu) {
        this.TenKhu = TenKhu;
    }

    @Override
    public String toString() {
        return MaKhu + " - " + TenKhu;
    }
       
}
