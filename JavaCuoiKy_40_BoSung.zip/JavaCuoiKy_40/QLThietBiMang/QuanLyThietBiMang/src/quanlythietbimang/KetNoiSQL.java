package quanlythietbimang;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class KetNoiSQL {
    private static Connection connection;
    private static final String DB_URL = "jdbc:sqlserver://localhost:1433; databaseName=QuanLyThietBi";
    private static final String DB_USER = "MinhThy";
    private static final String DB_PASSWORD = "nmthy3568";

   public static Connection getConnection() {
        try {
            return DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void closeConnection(Connection connection) {
        try {
            if (connection != null) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
