/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package quanlythietbimang;


public class LogThietBi {
    private ThietBi thietbi;
    private String thoigian;
    
    public LogThietBi(ThietBi thietbi, String thoigian) {
        this.thietbi = thietbi;
        this.thoigian = thoigian;
    }

    public ThietBi getThietbi() {
        return thietbi;
    }

    public void setThietbi(ThietBi thietbi) {
        this.thietbi = thietbi;
    }

    public String getThoigian() {
        return thoigian;
    }

    public void setThoigian(String thoigian) {
        this.thoigian = thoigian;
    }
    
}
