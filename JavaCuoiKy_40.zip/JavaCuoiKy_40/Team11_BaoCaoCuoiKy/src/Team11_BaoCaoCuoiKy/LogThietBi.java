/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Team11_BaoCaoCuoiKy;

/**
 *
 * @author ADMIN
 */
public class LogThietBi {
    private int MaTB;
    private String TenTB;
    private Boolean Online;
    private String ThoiGian;
    private String IP;

    public String getIP() {
        return IP;
    }

    public void setIP(String IP) {
        this.IP = IP;
    }
    public LogThietBi(int MaTB, String TenTB, String IP, Boolean Online, String ThoiGian) {
        this.MaTB = MaTB;
        this.TenTB = TenTB;
        this.Online = Online;
        this.ThoiGian = ThoiGian;
        this.IP = IP;
    }

    
    public int getMaTB() {
        return MaTB;
    }

    public void setMaTB(int MaTB) {
        this.MaTB = MaTB;
    }

    public String getTenTB() {
        return TenTB;
    }

    public void setTenTB(String TenTB) {
        this.TenTB = TenTB;
    }

    public Boolean getOnline() {
        return Online;
    }

    public void setOnline(Boolean Online) {
        this.Online = Online;
    }

    public String getThoiGian() {
        return ThoiGian;
    }

    public void setThoiGian(String ThoiGian) {
        this.ThoiGian = ThoiGian;
    }
    
    
}
