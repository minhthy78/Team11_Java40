/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Team11_BaoCaoCuoiKy;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DataController {

    public void addLog(int MaThietBi, Boolean TinhTrang) {
        try (
                Connection ketnoi = KetNoiDB.getConnection(); CallableStatement callableStatement = ketnoi.prepareCall("{call sp_LogThietBi_Insert(?,?)}")) {
            callableStatement.setInt(1, MaThietBi);
            callableStatement.setBoolean(2, TinhTrang);
            callableStatement.execute();
        } catch (SQLException loi) {
            System.err.println("Error execute sql: " + loi.getMessage());
        }
    }

    public void addDevice(String TenThietBi, String Ip, String Mac, int Loai, String MaKhu) {
        try (
                Connection ketnoi = KetNoiDB.getConnection(); CallableStatement callableStatement = ketnoi.prepareCall("{call sp_ThietBi_Insert(?,?,?,?,?)}")) {
            callableStatement.setString(1, TenThietBi);
            callableStatement.setString(2, Ip);
            callableStatement.setString(3, Mac);
            callableStatement.setInt(4, Loai);
            callableStatement.setString(5, MaKhu);
            callableStatement.execute();

        } catch (SQLException loi) {
            System.err.println("Error execute sql: " + loi.getMessage());
        }
    }
    
        

    public void updateDevice(String TenThietBi, String Ip, String Mac, int Loai, String MaKhu, int MaThietBi) {
        try (
                Connection ketnoi = KetNoiDB.getConnection(); CallableStatement callableStatement = ketnoi.prepareCall("{call sp_ThietBi_Update(?,?,?,?,?,?)}")) {
            callableStatement.setString(1, TenThietBi);
            callableStatement.setString(2, Ip);
            callableStatement.setString(3, Mac);
            callableStatement.setInt(4, Loai);
            callableStatement.setString(5, MaKhu);
            callableStatement.setInt(6, MaThietBi);
            
            callableStatement.execute();

        } catch (SQLException loi) {
            System.err.println("Error execute sql: " + loi.getMessage());
        }
    }

 

    public void deleteDevice(int MaThietBi) {
        try (
                Connection ketnoi = KetNoiDB.getConnection(); CallableStatement callableStatement = ketnoi.prepareCall("{call sp_ThietBi_Delete(?)}")) {
            callableStatement.setInt(1, MaThietBi);

            callableStatement.execute();
        } catch (SQLException loi) {
            System.err.println("Error execute sql: " + loi.getMessage());
        }
    }
    
    

    public static List<ThietBi> getAllDevices() {
//        do mình muốn dữ liệu trả về gán vào Jtable, mà Jtable nó có biến lưu là: tblThietBi kiểu data là tablemodel nên mình trả về LIST<ThietBi>
// từ List<ThietBi> minh mới gắn vào tableModel
        List<ThietBi> dsThietBi = new ArrayList<>();
        try (
                Connection ketnoi = KetNoiDB.getConnection(); // khởi tạo kn database
                 CallableStatement goiProc = ketnoi.prepareCall("{call sp_ThietBi_SelectAll()}");) {

            goiProc.execute(); // câu này chạy thủ tục (Proc) => ket quả sẽ lưu trong biến goiProc luôn
            ResultSet kq = goiProc.getResultSet(); // do ket qua tra ve kiểu Resultset
            // giờ có kq từ database trả về rồi, mình gán vào bảng, mình phải xác định cột nào sẽ ở vị trí nào trong bảng
            // đầu tiên mình tách từng dòng ra, trong từ dòng mình lấy ra từ cột
            while (kq.next()) {
                String ten = kq.getString("TenThietBi");
                int ma = kq.getInt("MaTB"); // Ten này phải giống bên database 
                String ip = kq.getString("IP");
                String mac = kq.getString("MAC");
                String hang = kq.getString("HangThietBi");

                Boolean trangThaiHoatDong = kq.getBoolean("TrangThaiHoatDong");
                String maKhu = kq.getString("MaKhu");
                String tenLoai = kq.getString("TenLoai");

                //gio gom het thông tin trên tạo thành biến ThietBi
                ThietBi thietbi = new ThietBi();
                thietbi.setMaTB(ma);
                thietbi.setTenTB(ten);
                thietbi.setMAC(mac);
                thietbi.setTenLoai(tenLoai);
                thietbi.setIP(ip);
                thietbi.setKhu(maKhu);

                thietbi.setTrangthaihoatdong(trangThaiHoatDong);

                // giờ thêm biết thietbi vào dsThietBi
                dsThietBi.add(thietbi);
                // vậy là sau khi chạy hết các dòng trong kq thì có bao nhiêu thiết bị sẽ add vào dsThietBi het.
            }
        } catch (SQLException err) {
            System.err.println("Error execute sql: " + err.getMessage());
        }
        // trả về dsThietBi
        return dsThietBi;

    }
    
    public static List<LogThietBi> getLogThietBi(int MaTB) {

        List<LogThietBi> dsLog = new ArrayList<>();
        try (
                Connection ketnoi = KetNoiDB.getConnection(); 
                 CallableStatement goiProc = ketnoi.prepareCall("{call sp_LogThietBi_SelectByID(?)}");) {
                 goiProc.setInt(1, MaTB);
            goiProc.execute(); 
            ResultSet kq = goiProc.getResultSet(); 
            while (kq.next()) {
                String ten = kq.getString("TenThietBi");
                int ma = kq.getInt("MaTB"); // Ten này phải giống bên database 
                String ip = kq.getString("IP");              
                Boolean trangThaiHoatDong = kq.getBoolean("TrangThaiHoatDong");
                String thoigian = kq.getString("ThoiGian");
                LogThietBi log = new LogThietBi(MaTB, ten,ip, trangThaiHoatDong, thoigian);
                
                // giờ thêm biết thietbi vào dsThietBi
                dsLog.add(log);
                // vậy là sau khi chạy hết các dòng trong kq thì có bao nhiêu thiết bị sẽ add vào dsThietBi het.
            }
        } catch (SQLException err) {
            System.err.println("Error execute sql: " + err.getMessage());
        }
        // trả về dsThietBi
        return dsLog;

    }
    
    

    public static List<LoaiThietBi> getLoaiThietBi() {
        List<LoaiThietBi> dsLoai = new ArrayList<>();
        try (
                Connection ketnoi = KetNoiDB.getConnection(); CallableStatement callableStatement = ketnoi.prepareCall("{call sp_LoaiThietBi_Select()}")) {
            callableStatement.execute();
            ResultSet kq = callableStatement.getResultSet();

            while (kq.next()) {
                String ten = kq.getString("TenLoai");
                int ma = kq.getInt("MaLoai");
                LoaiThietBi loaiThietBi = new LoaiThietBi(ma, ten);
                dsLoai.add(loaiThietBi);
            }

        } catch (SQLException loi) {
            System.err.println("Error execute sql: " + loi.getMessage());
        }
        return dsLoai;
    }

    public static List<String> getKhu() {
        List<String> dsKhu = new ArrayList<>();
        try (
                Connection ketnoi = KetNoiDB.getConnection(); CallableStatement callableStatement = ketnoi.prepareCall("{call sp_DiaDiem_SelectAll()}")) {
            callableStatement.execute();
            ResultSet kq = callableStatement.getResultSet();

            while (kq.next()) {
                String ma = kq.getString("MaKhu");
                dsKhu.add(ma);
            }
        } catch (SQLException loi) {
            System.err.println("Error execute sql: " + loi.getMessage());
        }
        return dsKhu;
    }

    public static boolean checkLogin(String Username, String Password) {
        boolean kq = false;

        try (
                Connection ketnoi = KetNoiDB.getConnection(); CallableStatement callableStatement = ketnoi.prepareCall("{call sp_TaiKhoan_DangNhap(?,?)}")) {
            callableStatement.setString(1, Username);
            callableStatement.setString(2, Password);
            callableStatement.execute();
            ResultSet kqDB = callableStatement.getResultSet();

            while (kqDB.next()) {
                int x = 0;
                x = kqDB.getInt("kq");
                BoNhoTam.setUsername(Username);
                BoNhoTam.setVaitro((Boolean)kqDB.getBoolean("VaiTro"));
                System.out.println(x);
                if (x == 0) {
                    kq = false;
                } else {
                    kq = true;
                }
            }

        } catch (SQLException loi) {
            System.err.println("Error execute sql: " + loi.getMessage());
        }
        return kq;
    }
}
