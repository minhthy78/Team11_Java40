/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Team11_BaoCaoCuoiKy;

import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author minhn
 */
public class InterfaceAdmin extends javax.swing.JFrame {

    public InterfaceAdmin() {
        initComponents();
        lblUsername.setText(BoNhoTam.getUsername());
        if (BoNhoTam.getVaitro() == false){
             btnSua.setEnabled(false);
             btnThem.setEnabled(false);
            btnXoa.setEnabled(false);
        }
       
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenu1 = new javax.swing.JMenu();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblThietBi = new javax.swing.JTable();
        btnThem = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        btnKiemTra = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        outputTextArea = new javax.swing.JTextArea();
        btnSua = new javax.swing.JButton();
        btnXoa = new javax.swing.JButton();
        btnXemLog = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        lblUsername = new javax.swing.JLabel();

        jMenu1.setText("jMenu1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 102));
        jLabel1.setText("QUẢN LÝ VÀ THEO DÕI THIẾT BỊ MẠNG");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 70, -1, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Team11_BaoCaoCuoiKy/header.png"))); // NOI18N
        jLabel2.setText("jLabel2");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 970, 191));

        tblThietBi.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Mã", "Tên thiết bị", "IP", "MAC", "Loại", "Khu", "Online"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Boolean.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tblThietBi);

        jPanel2.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 250, 560, 390));

        btnThem.setText("Thêm");
        btnThem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemActionPerformed(evt);
            }
        });
        jPanel2.add(btnThem, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 210, 70, 30));

        jButton3.setText("Thoát");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 210, 106, 30));

        btnKiemTra.setText("Kiểm tra thiết bị");
        btnKiemTra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnKiemTraActionPerformed(evt);
            }
        });
        jPanel2.add(btnKiemTra, new org.netbeans.lib.awtextra.AbsoluteConstraints(726, 210, 130, 30));

        jScrollPane2.setViewportBorder(javax.swing.BorderFactory.createTitledBorder("Log"));

        outputTextArea.setColumns(20);
        outputTextArea.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        outputTextArea.setRows(5);
        jScrollPane2.setViewportView(outputTextArea);

        jPanel2.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 250, 410, 390));

        btnSua.setText("Sửa");
        btnSua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaActionPerformed(evt);
            }
        });
        jPanel2.add(btnSua, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 210, 70, 30));

        btnXoa.setText("Xóa");
        btnXoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaActionPerformed(evt);
            }
        });
        jPanel2.add(btnXoa, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 210, 80, 30));

        btnXemLog.setText("Xem Log");
        btnXemLog.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXemLogActionPerformed(evt);
            }
        });
        jPanel2.add(btnXemLog, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 210, 90, 30));

        jLabel3.setText("User đăng nhập:");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 210, -1, -1));

        lblUsername.setText("__");
        jPanel2.add(lblUsername, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 210, 190, -1));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 0, 969, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnThemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemActionPerformed
        Add formThem = new Add();
        formThem.loadDataCB();
        formThem.setVisible(true);
        formThem.setLocationRelativeTo(null);
        formThem.addWindowListener(new WindowListener() {

            @Override
            public void windowOpened(WindowEvent e) {
            }

            @Override
            public void windowClosing(WindowEvent e) {

            }

            @Override
            public void windowClosed(WindowEvent e) {
                getDanhSachThietBi();
            }

            @Override
            public void windowIconified(WindowEvent e) {
            }

            @Override
            public void windowDeiconified(WindowEvent e) {
            }

            @Override
            public void windowActivated(WindowEvent e) {
            }

            @Override
            public void windowDeactivated(WindowEvent e) {
            }
        });
    }//GEN-LAST:event_btnThemActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        this.dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    
    
    
    private void btnKiemTraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnKiemTraActionPerformed
         outputTextArea.append(" \n ====Checking====" + '\n');
        AtomicInteger counter = new AtomicInteger(0);
        List<String> ipAddresses = new ArrayList<>();
        DefaultTableModel tbKiemTra = (DefaultTableModel) tblThietBi.getModel();
        for (int i = 0; i < tbKiemTra.getRowCount(); i++) {
            ipAddresses.add((String) tbKiemTra.getValueAt(i, 2));
        }
        ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);

        Runnable pingTask = () -> {
            int soLanChay = counter.incrementAndGet();
         
           
            for (String ipAddress : ipAddresses) {
                CompletableFuture<Boolean> pingResult = Ping.pingDevice(ipAddress);

                pingResult.thenAccept(result -> {

                    for (int i = 0; i < tbKiemTra.getRowCount(); i++) {

                        LocalDateTime currentTime = LocalDateTime.now();
                        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss dd/MM/yyyy");
                        String formattedTime = currentTime.format(formatter);
                        String ip = (String) tbKiemTra.getValueAt(i, 2);
                        if (ip.equals(ipAddress)) {
                            String tenTinhTrang;
                            if (result == true) {
                                tenTinhTrang = "online";
                            } else {
                                tenTinhTrang = "offline";
                            }
                            Boolean trangThaiHienTai = (Boolean) tbKiemTra.getValueAt(i, 6);
                            String tenTinhTrangHienTai;
                            if (trangThaiHienTai == true) {
                                tenTinhTrangHienTai = "online";
                            } else {
                                tenTinhTrangHienTai = "offline";
                            }
                            tbKiemTra.setValueAt(result, i, 6);

                            outputTextArea.append("\n" + tbKiemTra.getValueAt(i, 1) + " - " + ipAddress + " - " + tenTinhTrang + " -  " + formattedTime );
                            
                            if (soLanChay > 1) {

                                outputTextArea.append("\n" + ip + "=> TT: " + trangThaiHienTai + " | kq: " + result);

                                // nếu thiết bị từ offline chuyển sang online
                                if (result == true && trangThaiHienTai == false) {
                                    
                                    DataController db = new DataController();
                                    db.addLog((int) tblThietBi.getValueAt(i, 0), result);
                                    String to = "nguyenminhth07082003@gmail.com";
                                    outputTextArea.append("\n" + ip + "Đã gửi mail: " + to);

                                    String subject = "Thông báo tình trạng thiết bị mạng online";
                                    String message = tbKiemTra.getValueAt(i, 1) + " - " + ipAddress + " - " + tenTinhTrang + " -  " + formattedTime + "\n";

                                    EmailSender mail = new EmailSender();
                                    mail.sendEmail(to, subject, message);

                                } else {
                                    // thiết bị từ onine chuyển sang offline
                                    if (result == false && trangThaiHienTai == true) {
                                        DataController db = new DataController();
                                        db.addLog((int) tblThietBi.getValueAt(i, 0), result);
                                        String to = "nguyenminhth07082003@gmail.com";
                                        outputTextArea.append("\n" + ip + "Đã gửi mail: " + to);

                                        String subject = "Thông báo tình trạng thiết bị mạng offline";
                                        String message = tbKiemTra.getValueAt(i, 1) + " - " + ipAddress + " - " + tenTinhTrang + " -  " + formattedTime + "\n";

                                        EmailSender mail = new EmailSender();
                                        mail.sendEmail(to, subject, message);

                                    }

                                }
                            }
                            
                            outputTextArea.setCaretPosition(outputTextArea.getText().length());

                        }

                    }
//                    tableModel.setValueAt(result, tableModel.fi, NORMAL);
                });
            };

        };

        // Lên lịch thực hiện ping mỗi 5 giây
        executor.scheduleAtFixedRate(pingTask, 2, 5, TimeUnit.SECONDS);
    }//GEN-LAST:event_btnKiemTraActionPerformed

    private void btnSuaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuaActionPerformed
        int dongDangChon = tblThietBi.getSelectedRow();
        ThietBi tb = new ThietBi();
        tb.setMaTB((int) tblThietBi.getValueAt(dongDangChon, 0));
        tb.setIP((String) tblThietBi.getValueAt(dongDangChon, 2));
        tb.setTenTB((String) tblThietBi.getValueAt(dongDangChon, 1));
        tb.setMAC((String) tblThietBi.getValueAt(dongDangChon, 3));
        tb.setTenLoai((String) tblThietBi.getValueAt(dongDangChon, 4));
        tb.setKhu((String) tblThietBi.getValueAt(dongDangChon, 5));

        Update fupdate = new Update();
        fupdate.loadData(tb);
        fupdate.setVisible(true);
        fupdate.addWindowListener(new WindowListener() {
            @Override
            public void windowOpened(WindowEvent e) {
               
            }

            @Override
            public void windowClosing(WindowEvent e) {
            }

            @Override
            public void windowClosed(WindowEvent e) {
                getDanhSachThietBi();
            }

            @Override
            public void windowIconified(WindowEvent e) {
            }

            @Override
            public void windowDeiconified(WindowEvent e) {
            }

            @Override
            public void windowActivated(WindowEvent e) {
            }

            @Override
            public void windowDeactivated(WindowEvent e) {
            }
        });

    }//GEN-LAST:event_btnSuaActionPerformed

    private void btnXoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaActionPerformed

        DataController db = new DataController();
        int dongDangChon = tblThietBi.getSelectedRow();
        int matb = (int) tblThietBi.getValueAt(dongDangChon, 0);
        db.deleteDevice(matb);
        getDanhSachThietBi();
    }//GEN-LAST:event_btnXoaActionPerformed

    private void btnXemLogActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXemLogActionPerformed
        // TODO add your handling code here:
        formLog flog = new formLog();
        int dongDangChon = tblThietBi.getSelectedRow();
        int matb = (int) tblThietBi.getValueAt(dongDangChon, 0);
       flog.getLogThietBi(matb);
       flog.setVisible(true);
    }//GEN-LAST:event_btnXemLogActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */

        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(InterfaceAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(InterfaceAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(InterfaceAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(InterfaceAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
//                new InterfaceAdmin().setVisible(true);
                

            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnKiemTra;
    private javax.swing.JButton btnSua;
    private javax.swing.JButton btnThem;
    private javax.swing.JButton btnXemLog;
    private javax.swing.JButton btnXoa;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblUsername;
    private javax.swing.JTextArea outputTextArea;
    private javax.swing.JTable tblThietBi;
    // End of variables declaration//GEN-END:variables

    // giờ tạo hàm load thiết bị để khi nào cần gọi lên thôi
    public void getDanhSachThietBi() {
        DefaultTableModel dulieuBang = (DefaultTableModel) tblThietBi.getModel(); // tạo một biết link với dữ liệu của bảng
        dulieuBang.setRowCount(0); // câu này để xóa bảng mỗi khi gọi, xóa dữ liệu đang có,,,lấy dữ liệu mới gán vào
        // giờ đi lấy data từ database
        List<ThietBi> dsThietBi = DataController.getAllDevices();
        // lấy dsThietbi gan vào dulieuBang
        for (ThietBi tb : dsThietBi) {
            dulieuBang.addRow(new Object[]{tb.getMaTB(), tb.getTenTB(), tb.getIP(), tb.getMAC(), tb.getTenLoai(), tb.getKhu(), tb.getTrangthaihoatdong()}); // do mình chưa có máy cột sau nên để null
        }

    }
}
