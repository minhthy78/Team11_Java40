/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Team11_BaoCaoCuoiKy;

/**
 *
 * @author ADMIN
 */
public class ThietBi {
    private int MaTB;
    private String TenTB;
    private String IP;
    private String MAC;
    private String HangTB;
    private int TinhtrangTB;
    private Boolean Trangthaihoatdong;

    public Boolean getTrangthaihoatdong() {
        return Trangthaihoatdong;
    }

    public void setTrangthaihoatdong(Boolean Trangthaihoatdong) {
        this.Trangthaihoatdong = Trangthaihoatdong;
    }
    private String TenLoai;
    private String Khu;

    public String getKhu() {
        return Khu;
    }

    public void setKhu(String Khu) {
        this.Khu = Khu;
    }
    
    public String getTenLoai() {
        return TenLoai;
    }

    public void setTenLoai(String TenLoai) {
        this.TenLoai = TenLoai;
    }

    public String getTenTinhTrangTB() {
        return TenTinhTrangTB;
    }

    public void setTenTinhTrangTB(String TenTinhTrangTB) {
        this.TenTinhTrangTB = TenTinhTrangTB;
    }
    private String TenTinhTrangTB;


    public String getIP() {
        return IP;
    }

    public void setIP(String IP) {
        this.IP = IP;
    }

    public String getMAC() {
        return MAC;
    }

    public void setMAC(String MAC) {
        this.MAC = MAC;
    }

    public String getHangTB() {
        return HangTB;
    }

    public void setHangTB(String HangTB) {
        this.HangTB = HangTB;
    }

    public int getTinhtrangTB() {
        return TinhtrangTB;
    }

    public void setTinhtrangTB(int TinhtrangTB) {
        this.TinhtrangTB = TinhtrangTB;
    }


    public boolean isTrangthaihoatdong() {
        return Trangthaihoatdong;
    }

    public void setTrangthaihoatdong(boolean Trangthaihoatdong) {
        this.Trangthaihoatdong = Trangthaihoatdong;
    }

    public int getMaTB() {
        return MaTB;
    }

    public void setMaTB(int MaTB) {
        this.MaTB = MaTB;
    }

    public String getTenTB() {
        return TenTB;
    }

    public void setTenTB(String TenTB) {
        this.TenTB = TenTB;
    }
}
